
package com.egg.springLibrary.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author irina
 */
@Controller
@RequestMapping("/author")
public class AuthorController {
    @GetMapping("/form")
    public String author(){
        return "author_form.html";
    }
}
