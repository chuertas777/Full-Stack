
package com.egg.springLibrary.excepciones;

/**
 *
 * @author irina
 */
public class MyException extends Exception{

    public MyException(String msg) {
        super(msg);
    }
    
    
}
