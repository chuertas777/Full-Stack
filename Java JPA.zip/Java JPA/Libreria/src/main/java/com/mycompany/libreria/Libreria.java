/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.libreria;

import Libreria.persistencia.ControladoraPersistencia;

/**
 *
 * @author CamiloH
 */
public class Libreria {

    public static void main(String[] args) {
        
        ControladoraPersistencia cp = new ControladoraPersistencia();
        
        
        
    }
}
